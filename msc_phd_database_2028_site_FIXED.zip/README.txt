MSc / PhD Database 2028 — Google Sheets sync fix

WHAT WAS FIXED
The old sync button called `claude.use('mcp')`. That object does not exist
on a normal GitHub Pages website, which caused: "claude is not defined".
The updated index.html reads the two configured tabs directly through the
Google Sheets Visualization endpoint. The dashboard, charts, filters,
shortlist, CSV export, and application-status features are retained.

REQUIRED ONE-TIME GOOGLE SHEETS SETTING
1. Open the spreadsheet configured in index.html.
2. Click Share.
3. Under General access, choose "Anyone with the link" and set role to
   "Viewer". Save.
4. Confirm the sheet tabs are named exactly:
   - BUTEX Foreign
   - BUTEX Govt.
5. The code reads ranges A5:L400 and A2:H400 respectively.

PRIVACY NOTE
Anyone who obtains the spreadsheet link may be able to view the shared
spreadsheet. Only enable link sharing if the data in those tabs is suitable
for public viewing. Do not put private contact details or sensitive data in
those tabs. This is a read-only sync; the website does not write to Sheets.

PUBLISH TO GITHUB PAGES
1. Download and extract this ZIP.
2. In your GitHub repository, replace the existing root-level index.html
   with the new index.html from this ZIP.
3. Commit the change to the main branch.
4. Wait for GitHub Pages to rebuild, then refresh the website.
5. Open the BUTEX alumni tab and press "Sync from Google Sheet".

If sync still fails, read the message shown beside the sync button. The most
common remaining cause is that the spreadsheet is not shared for link viewing
or that a tab name/range has changed.
